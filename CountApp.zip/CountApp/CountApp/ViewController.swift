//
//  ViewController.swift
//  CountApp
//
//  Created by 亀田直輝 on 2020/04/07.
//  Copyright © 2020 亀田直輝. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var label: UILabel!
    ///変数を宣言する。
    //加えられる数を入れる変数。
    var number1:Int = 0
    //加える数を入れる変数。
    var number2:Int = 0
    //計算結果を入れる変数。
    var number3:Int = 0
    //どの四則演算をするかを判定するための変数。
    var ope:Int = 0
    
    ///コードを読み込む時に、一番最初に読むコード。
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //labelには、最初から０を表示する。
        label.text = "0"
    }//viewDidLoad

   ///「3」ボタンの処理。
    @IBAction func threeButton(_ sender: Any) {
        //加えられる数と加える数どちらに数を入れるか。
        if (ope != 1){
            number1 = (number1 * 10) + 3
            //labelに表示する。
            label.text = String(number1)
        }else{
            //加える数に数を入れる。
            number2 = (number2 * 10) + 3
            
            label.text = String(number2)
        }//else
    }//threeButton
    ///「4」ボタンの処理。
    @IBAction func fourButton(_ sender: Any) {
        //加えられる数と加える数どちらに数を入れるか。
        if (ope != 1){
            number1 = (number1 * 10) + 4
             //labelに表示する。
            label.text = String(number1)
        }else{
            //加える数に数を入れる。
            number2 = (number2 * 10) + 4
            label.text = String(number2)
        }//else
    }//fourButton
    
    ///「＋」のボタンの処理
    @IBAction func plusButton(_ sender: Any) {
        //「＋」が押される時を制限する。
        if (number1 != 0 && number2 == 0 ){
            //opeが1の時は「＋」が押されたことを表す。
                ope = 1
            //labelに表示する。
               label.text = "＋"
               print("「＋」ボタンが押されました。")
        }else{
            return
        }
    }
    ///「=」のボタンの処理
    @IBAction func equalButton(_ sender: Any) {
        //number1とnumber2に数が代入されているか。
               if (number1 > 0 && number2 > 0){
                //合計をnumber3の変数に入れる。
                   number3 = number1 + number2
                   print("「＝」が押されました。")
                   //Int型をString型に変換（キャスト）。
                   label.text = String(number3)
               }else{
                   return
               }//else
    }//equalButton
    ///「AC」ボタンの処理。
    @IBAction func acButton(_ sender: Any) {
        //number1を０にする。
        number1 = 0
        //number2を０にする。
        number2 = 0
        //number3を０にする。
        number3 = 0
        //labelを０にする。
        label.text = String(number3)
        //opeを０にする。
        ope = 0
    }//acButton
    
    
}

