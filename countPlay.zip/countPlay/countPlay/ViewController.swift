//
//  ViewController.swift
//  countPlay
//
//  Created by 亀田直輝 on 2020/04/06.
//  Copyright © 2020 亀田直輝. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
//計算結果を表示するためのラベル
    @IBOutlet weak var label: UILabel!
    //加えられる数を入れる変数。
    var number1:Int = 0
    //加える数を入れる変数。
    var number2:Int = 0
    //計算結果を入れる変数。
    var number3:Int = 0
    //どの四則演算をするかを判定するための変数
    var ope:Int = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        label.text = "0"
    }
///「3」ボタンの処理。
    @IBAction func threeButton(_ sender: Any) {
        if (ope != 1){
            if(number1 == 0){
                number1 = 3
                label.text = String(number1)
                print("１の位に代入しました。")
            }else if (number1 < 10){
                number1 = (number1*10) + 3
                label.text = String(number1)
                print("１０の位に代入しました。")
            }else{
                number1 = (number1*100) + 3
                label.text = String(number1)
                print("１００の位に代入しました。")
            }//else
        }else{
            if (number2 == 0){
                number2 = 3
                label.text = String(number2)
                print("number2の１の位に代入しました。")
            }else if (number2 < 10){
                number2 = (number2*10) + 3
                label.text = String(number2)
                print("number2の10の位に代入しました。")
            }else{
                number2 = (number2*100) + 3
                label.text = String(number2)
                print("number2の100の位に代入しました。")
            }//else
        }//ope
    }//threeButton
    ///「４」のボタンの処理
    @IBAction func fourBuuton(_ sender: Any) {
        if (ope != 1){
                if(number1 == 0){
                    number1 = 4
                    label.text = String(number1)
                    print("１の位に代入しました。")
                }else if (number1 < 10){
                    number1 = (number1*10) + 4
                    label.text = String(number1)
                    print("１０の位に代入しました。")
                }else{
                    number1 = (number1*100) + 4
                    label.text = String(number1)
                    print("１００の位に代入しました。")
                }//else
            }else{
                if (number2 == 0){
                    number2 = 4
                    label.text = String(number2)
                    print("number2の１の位に代入しました。")
                }else if (number2 < 10){
                    number2 = (number2*10) + 4
                    label.text = String(number2)
                    print("number2の10の位に代入しました。")
                }else{
                    number2 = (number2*100) + 4
                    label.text = String(number2)
                    print("number2の100の位に代入しました。")
                }//else
            }//ope
        
    }//fourButton
    ///「=」のボタンの処理
    @IBAction func equalButton(_ sender: Any) {
        //number1とnumber2に数が代入されているか。
        if (number1 > 0 && number2 > 0){
            number3 = number1 + number2
            print("「＝」が押されました。")
            //Int型をString型に変換（キャスト）。
            label.text = String(number3)
        }else{
            return
        }//else
    }//equalButton
    
    ///「＋」のボタンの処理
    @IBAction func plusButton(_ sender: Any) {
        ope = 1
        label.text = "＋"
        print("「＋」ボタンが押されました。")
    }//plusButton
    
    @IBAction func acButton(_ sender: Any) {
        //number1を０にする。
        number1 = 0
        //number2を０にする。
        number2 = 0
        //number3を０にする。
        number3 = 0
        //labelを０にする。
        label.text = String(number3)
        //opeを０にする。
        ope = 0
        
    }//acButton
    
    
    
}//ViewController

